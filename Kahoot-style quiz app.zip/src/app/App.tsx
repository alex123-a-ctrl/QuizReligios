import { useState } from 'react';
import { StartScreen } from './components/StartScreen';
import { QuizQuestion } from './components/QuizQuestion';
import { ResultsScreen } from './components/ResultsScreen';
import { motion } from 'motion/react';

interface Question {
  id: number;
  question: string;
  image: string;
  answers: Array<{
    id: number;
    text: string;
    isCorrect: boolean;
  }>;
}

const questions: Question[] = [
  {
    id: 1,
    question: 'Ce este Spovedania?',
    image: 'https://images.unsplash.com/photo-1748510280927-fff44eceefce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcnRob2RveCUyMGNodXJjaCUyMGNvbmZlc3Npb258ZW58MXx8fHwxNzczMjQ4MTU1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Un ritual de curățire fizică', isCorrect: false },
      { id: 2, text: 'Mărturisirea păcatelor în fața preotului', isCorrect: true },
      { id: 3, text: 'O rugăciune de seară', isCorrect: false },
      { id: 4, text: 'Un post prelungit', isCorrect: false },
    ],
  },
  {
    id: 2,
    question: 'Ce primim la Sfânta Împărtășanie?',
    image: 'https://images.unsplash.com/photo-1731742274419-bf3748045fbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pb24lMjBjaGFsaWNlJTIwY2h1cmNofGVufDF8fHx8MTc3MzI0ODE1NXww&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Apă sfințită', isCorrect: false },
      { id: 2, text: 'Pâine și vin obișnuit', isCorrect: false },
      { id: 3, text: 'Trupul și Sângele lui Hristos', isCorrect: true },
      { id: 4, text: 'Mirul', isCorrect: false },
    ],
  },
  {
    id: 3,
    question: 'Cine ne poate da dezlegare la Spovedanie?',
    image: 'https://images.unsplash.com/photo-1762399940362-9ed7d199b72e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmllc3QlMjBvcnRob2RveCUyMGJsZXNzaW5nfGVufDF8fHx8MTc3MzI0ODE1NXww&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Părinții noștri', isCorrect: false },
      { id: 2, text: 'Preotul, prin puterea dată de Dumnezeu', isCorrect: true },
      { id: 3, text: 'Orice credincios', isCorrect: false },
      { id: 4, text: 'Nimeni, ne iertăm singuri', isCorrect: false },
    ],
  },
  {
    id: 4,
    question: 'Ce trebuie să facem înainte de a ne împărtăși?',
    image: 'https://images.unsplash.com/photo-1649485141888-f018963d585c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaHJpc3RpYW4lMjBjcm9zcyUyMGxpZ2h0fGVufDF8fHx8MTc3MzI0ODE1Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Să postim și să ne spovedim', isCorrect: true },
      { id: 2, text: 'Să dormim mult', isCorrect: false },
      { id: 3, text: 'Să dăm bani la biserică', isCorrect: false },
      { id: 4, text: 'Să citim ziarul', isCorrect: false },
    ],
  },
  {
    id: 5,
    question: 'La Spovedanie trebuie să fim:',
    image: 'https://images.unsplash.com/photo-1559536454-5a69386e8075?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaHVyY2glMjBpbnRlcmlvciUyMGNhbmRsZXN8ZW58MXx8fHwxNzczMTczMzY3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Sinceri și pocăiți', isCorrect: true },
      { id: 2, text: 'Veseli și zgomotoși', isCorrect: false },
      { id: 3, text: 'Grăbiți și nervoși', isCorrect: false },
      { id: 4, text: 'Mândri de noi', isCorrect: false },
    ],
  },
  {
    id: 6,
    question: 'Ce folosește preotul la Sfânta Împărtășanie?',
    image: 'https://images.unsplash.com/photo-1628519750328-a5965788e475?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob2x5JTIwYnJlYWQlMjB3aW5lfGVufDF8fHx8MTc3MzI0ODE1N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Paharul și farfuria', isCorrect: false },
      { id: 2, text: 'Potir și linguriță', isCorrect: true },
      { id: 3, text: 'Cana și lingura', isCorrect: false },
      { id: 4, text: 'Cupa și furculița', isCorrect: false },
    ],
  },
  {
    id: 7,
    question: 'Cât de des ar trebui să ne spovedim?',
    image: 'https://images.unsplash.com/photo-1748510280927-fff44eceefce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcnRob2RveCUyMGNodXJjaCUyMGNvbmZlc3Npb258ZW58MXx8fHwxNzczMjQ4MTU1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'O dată pe an', isCorrect: false },
      { id: 2, text: 'Niciodată', isCorrect: false },
      { id: 3, text: 'Regulat, după nevoile sufletești', isCorrect: true },
      { id: 4, text: 'Doar când suntem bolnavi', isCorrect: false },
    ],
  },
  {
    id: 8,
    question: 'Ce nu trebuie să facem după Împărtășanie?',
    image: 'https://images.unsplash.com/photo-1731742274419-bf3748045fbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pb24lMjBjaGFsaWNlJTIwY2h1cmNofGVufDF8fHx8MTc3MzI0ODE1NXww&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Să ne rugăm', isCorrect: false },
      { id: 2, text: 'Să scuipăm', isCorrect: true },
      { id: 3, text: 'Să mulțumim lui Dumnezeu', isCorrect: false },
      { id: 4, text: 'Să sărutăm icoana', isCorrect: false },
    ],
  },
  {
    id: 9,
    question: 'Spovedania este numită și:',
    image: 'https://images.unsplash.com/photo-1762399940362-9ed7d199b72e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmllc3QlMjBvcnRob2RveCUyMGJsZXNzaW5nfGVufDF8fHx8MTc3MzI0ODE1NXww&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Botez', isCorrect: false },
      { id: 2, text: 'Pocăință sau Mărturisire', isCorrect: true },
      { id: 3, text: 'Cununie', isCorrect: false },
      { id: 4, text: 'Liturghie', isCorrect: false },
    ],
  },
  {
    id: 10,
    question: 'De ce ne împărtășim?',
    image: 'https://images.unsplash.com/photo-1649485141888-f018963d585c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaHJpc3RpYW4lMjBjcm9zcyUyMGxpZ2h0fGVufDF8fHx8MTc3MzI0ODE1Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    answers: [
      { id: 1, text: 'Pentru a ne uni cu Hristos', isCorrect: true },
      { id: 2, text: 'Pentru a ne face frumoși', isCorrect: false },
      { id: 3, text: 'Pentru a primi bani', isCorrect: false },
      { id: 4, text: 'Pentru a fi celebri', isCorrect: false },
    ],
  },
];

type GameState = 'start' | 'quiz' | 'results';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('start');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);

  const handleStart = () => {
    setGameState('quiz');
    setCurrentQuestionIndex(0);
    setScore(0);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  const handleAnswerSelect = (answerId: number) => {
    setSelectedAnswer(answerId);
    setShowResult(true);

    const currentQuestion = questions[currentQuestionIndex];
    const selectedAnswerObj = currentQuestion.answers.find((a) => a.id === answerId);

    if (selectedAnswerObj?.isCorrect) {
      setScore((prev) => prev + 1);
    }

    // Auto advance to next question after 2 seconds
    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex((prev) => prev + 1);
        setSelectedAnswer(null);
        setShowResult(false);
      } else {
        setGameState('results');
      }
    }, 2000);
  };

  const handleRestart = () => {
    setGameState('start');
    setCurrentQuestionIndex(0);
    setScore(0);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  if (gameState === 'start') {
    return <StartScreen onStart={handleStart} />;
  }

  if (gameState === 'results') {
    return (
      <ResultsScreen
        score={score}
        totalQuestions={questions.length}
        onRestart={handleRestart}
      />
    );
  }

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 p-4 py-8">
      {/* Progress Bar */}
      <div className="max-w-5xl mx-auto mb-6">
        <div className="bg-white/30 rounded-full h-4 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{
              width: `${((currentQuestionIndex + 1) / questions.length) * 100}%`,
            }}
            className="h-full bg-white rounded-full"
            transition={{ duration: 0.5 }}
          />
        </div>
        <div className="text-white text-center mt-2 text-xl font-bold">
          Întrebarea {currentQuestionIndex + 1} din {questions.length}
        </div>
        <div className="text-white text-center mt-1 text-lg">
          Scor: {score}
        </div>
      </div>

      <QuizQuestion
        question={currentQuestion.question}
        image={currentQuestion.image}
        answers={currentQuestion.answers}
        selectedAnswer={selectedAnswer}
        onAnswerSelect={handleAnswerSelect}
        showResult={showResult}
      />
    </div>
  );
}
