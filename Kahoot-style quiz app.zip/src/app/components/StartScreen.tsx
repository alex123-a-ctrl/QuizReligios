import { motion } from 'motion/react';
import { Play, BookOpen } from 'lucide-react';

interface StartScreenProps {
  onStart: () => void;
}

export function StartScreen({ onStart }: StartScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 flex items-center justify-center p-4">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-3xl shadow-2xl p-12 text-center max-w-2xl w-full"
      >
        <motion.div
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
          className="flex justify-center mb-6"
        >
          <BookOpen className="w-24 h-24 text-purple-600" />
        </motion.div>

        <h1 className="text-5xl font-bold text-gray-800 mb-4">
          Quiz Religios
        </h1>

        <p className="text-2xl text-gray-600 mb-8">
          Spovedanie și Împărtășanie
        </p>

        <div className="bg-purple-50 rounded-xl p-6 mb-8">
          <p className="text-lg text-gray-700">
            Testează-ți cunoștințele despre Spovedanie și Sfânta Împărtășanie!
          </p>
          <p className="text-md text-gray-600 mt-2">
            10 întrebări cu imagini
          </p>
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onStart}
          className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-2xl font-bold py-6 px-12 rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center gap-3 mx-auto"
        >
          <Play className="w-8 h-8" fill="currentColor" />
          Începe Quiz-ul
        </motion.button>
      </motion.div>
    </div>
  );
}
