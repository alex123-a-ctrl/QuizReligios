import { motion } from 'motion/react';
import { CheckCircle2, XCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Answer {
  id: number;
  text: string;
  isCorrect: boolean;
}

interface QuizQuestionProps {
  question: string;
  image: string;
  answers: Answer[];
  selectedAnswer: number | null;
  onAnswerSelect: (id: number) => void;
  showResult: boolean;
}

const colors = [
  'bg-red-500 hover:bg-red-600',
  'bg-blue-500 hover:bg-blue-600',
  'bg-amber-500 hover:bg-amber-600',
  'bg-green-500 hover:bg-green-600',
];

export function QuizQuestion({
  question,
  image,
  answers,
  selectedAnswer,
  onAnswerSelect,
  showResult,
}: QuizQuestionProps) {
  return (
    <div className="w-full max-w-5xl mx-auto">
      {/* Question and Image */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-2xl shadow-2xl p-8 mb-6"
      >
        <h2 className="text-3xl font-bold text-center mb-6 text-gray-800">
          {question}
        </h2>
        <div className="relative w-full h-64 rounded-xl overflow-hidden">
          <ImageWithFallback
            src={image}
            alt="Question image"
            className="w-full h-full object-cover"
          />
        </div>
      </motion.div>

      {/* Answers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {answers.map((answer, index) => {
          const isSelected = selectedAnswer === answer.id;
          const showCorrect = showResult && answer.isCorrect;
          const showWrong = showResult && isSelected && !answer.isCorrect;

          return (
            <motion.button
              key={answer.id}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => !showResult && onAnswerSelect(answer.id)}
              disabled={showResult}
              className={`
                ${colors[index]}
                text-white p-6 rounded-xl text-xl font-bold
                transition-all duration-300 transform
                ${!showResult ? 'hover:scale-105 cursor-pointer' : 'cursor-default'}
                ${isSelected && !showResult ? 'ring-4 ring-white scale-105' : ''}
                ${showCorrect ? 'ring-4 ring-green-300' : ''}
                ${showWrong ? 'ring-4 ring-red-300 opacity-50' : ''}
                relative overflow-hidden
                disabled:cursor-not-allowed
              `}
            >
              <span className="relative z-10 flex items-center justify-between">
                <span>{answer.text}</span>
                {showCorrect && (
                  <CheckCircle2 className="w-8 h-8 animate-bounce" />
                )}
                {showWrong && <XCircle className="w-8 h-8" />}
              </span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
