import { motion } from 'motion/react';
import { Trophy, RotateCcw, Star } from 'lucide-react';

interface ResultsScreenProps {
  score: number;
  totalQuestions: number;
  onRestart: () => void;
}

export function ResultsScreen({
  score,
  totalQuestions,
  onRestart,
}: ResultsScreenProps) {
  const percentage = (score / totalQuestions) * 100;

  const getMessage = () => {
    if (percentage === 100) return '🌟 Perfect! Felicitări!';
    if (percentage >= 80) return '✨ Foarte bine!';
    if (percentage >= 60) return '👍 Bine!';
    if (percentage >= 40) return '💪 Poți mai mult!';
    return '📚 Mai studiază puțin!';
  };

  const getColor = () => {
    if (percentage >= 80) return 'from-green-500 to-emerald-600';
    if (percentage >= 60) return 'from-blue-500 to-cyan-600';
    if (percentage >= 40) return 'from-amber-500 to-orange-600';
    return 'from-red-500 to-pink-600';
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br ${getColor()} flex items-center justify-center p-4`}>
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-3xl shadow-2xl p-12 text-center max-w-2xl w-full"
      >
        <motion.div
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 1, ease: 'easeInOut' }}
          className="flex justify-center mb-6"
        >
          <Trophy className="w-32 h-32 text-yellow-500" />
        </motion.div>

        <h1 className="text-5xl font-bold text-gray-800 mb-4">
          Rezultate
        </h1>

        <div className="text-6xl font-bold text-gray-800 mb-4">
          {score} / {totalQuestions}
        </div>

        <div className="text-3xl font-bold mb-8" style={{ color: percentage >= 60 ? '#10b981' : '#ef4444' }}>
          {percentage.toFixed(0)}%
        </div>

        <div className="bg-purple-50 rounded-xl p-6 mb-8">
          <p className="text-3xl font-bold text-gray-700">{getMessage()}</p>
        </div>

        <div className="flex gap-3 justify-center mb-6">
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ scale: 0 }}
              animate={{ scale: i < Math.round(percentage / 20) ? 1 : 0.3 }}
              transition={{ delay: i * 0.1 }}
            >
              <Star
                className="w-12 h-12"
                fill={i < Math.round(percentage / 20) ? '#fbbf24' : '#d1d5db'}
                color={i < Math.round(percentage / 20) ? '#fbbf24' : '#d1d5db'}
              />
            </motion.div>
          ))}
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onRestart}
          className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-2xl font-bold py-6 px-12 rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center gap-3 mx-auto"
        >
          <RotateCcw className="w-8 h-8" />
          Încearcă din nou
        </motion.button>
      </motion.div>
    </div>
  );
}
