
  # Kahoot-style quiz app

  This is a code bundle for Kahoot-style quiz app. The original project is available at https://www.figma.com/design/ywWTgnTcq72ZuTdeut9uNU/Kahoot-style-quiz-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  